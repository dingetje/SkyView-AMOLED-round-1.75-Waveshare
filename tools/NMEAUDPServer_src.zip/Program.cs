﻿namespace NMEAUDPServer
{
    using System;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;
    using System.Text;

    class NmeaUdpSender
    {
        static void Main(string[] args)
        {
            // Default values
            var filePath = "";
            var destinationIps = new List<string> { "192.168.1.161", "192.168.1.147" };
            var destinationPort = 10110;
            var delayMilliseconds = 250;

            // Parse command line arguments
            if (args.Length > 0)
            {
                // First argument is the file path
                filePath = args[0];

                // Remaining arguments are IP addresses
                if (args.Length > 1)
                {
                    destinationIps = args.Skip(1).ToList();
                }
            }
            else
            {
                Console.WriteLine("Usage: NMEAUDPServer.exe <filepath> [ip1 ip2 ip3 ...]");
                Console.WriteLine("Example: NMEAUDPServer.exe Data\\PowerMouse_Simulation_S1.txt 192.168.1.5");
                return;
            }

            if (!File.Exists(filePath))
            {
                Console.WriteLine($"[ERROR] File not found: {filePath}");
                Console.WriteLine("Usage: NMEAUDPServer.exe <filepath> [ip1 ip2 ip3 ...]");
                Console.WriteLine("Example: NMEAUDPServer.exe Data\\PowerMouse_Simulation_S1.txt 192.168.1.5");
                return;
            }

            try
            {
                using (UdpClient udpClient = new UdpClient())
                {
                    while (true)
                    {
                        foreach (string line in File.ReadLines(filePath))
                        {
                            if (string.IsNullOrWhiteSpace(line) || !line.StartsWith("$"))
                                continue;

                            // Send full sentence as one UDP packet
                            byte[] data = Encoding.ASCII.GetBytes(line + "\r\n");
                            foreach (var ip in destinationIps)
                            {
                                udpClient.Send(data, data.Length, ip, destinationPort);
                            }
                            Console.WriteLine($"Sent: {line.Trim()} to {string.Join(", ", destinationIps)}");

                            Thread.Sleep(delayMilliseconds);
                        }

                        Console.WriteLine("[INFO] All NMEA sentences sent line-by-line with corrected checksums, loop again...");
                        Console.WriteLine("[INFO] Type Ctrl-C to abort!");
                        Thread.Sleep(8000);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] {ex.Message}");
            }
        }
    }
}
